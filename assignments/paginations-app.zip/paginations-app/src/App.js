import './App.css';
import Posts from './components/pagination';

function App() {
  return (
    <div className="App">
      <Posts />
    </div>
  );
}

export default App;
